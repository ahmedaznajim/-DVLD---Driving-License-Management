﻿namespace DVLI.Licence
{
    partial class FormViewLicenceHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.viewLicenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.renewDrivingLicenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.replacmentForDamegedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.replacmentForLostToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.detainedLicenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relaeasLicenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(174, 253);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(571, 57);
            this.label1.TabIndex = 5;
            this.label1.Text = "Driving Licence History";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.ContextMenuStrip = this.contextMenuStrip1;
            this.dataGridView1.Location = new System.Drawing.Point(24, 331);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(905, 267);
            this.dataGridView1.TabIndex = 3;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewLicenceToolStripMenuItem,
            this.renewDrivingLicenceToolStripMenuItem,
            this.refreshToolStripMenuItem,
            this.replacmentForDamegedToolStripMenuItem,
            this.replacmentForLostToolStripMenuItem,
            this.detainedLicenceToolStripMenuItem,
            this.relaeasLicenceToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(257, 172);
            // 
            // viewLicenceToolStripMenuItem
            // 
            this.viewLicenceToolStripMenuItem.Name = "viewLicenceToolStripMenuItem";
            this.viewLicenceToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.viewLicenceToolStripMenuItem.Text = "View Licence";
            this.viewLicenceToolStripMenuItem.Click += new System.EventHandler(this.viewLicenceToolStripMenuItem_Click);
            // 
            // renewDrivingLicenceToolStripMenuItem
            // 
            this.renewDrivingLicenceToolStripMenuItem.Name = "renewDrivingLicenceToolStripMenuItem";
            this.renewDrivingLicenceToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.renewDrivingLicenceToolStripMenuItem.Text = "Renew Driving Licence";
            this.renewDrivingLicenceToolStripMenuItem.Click += new System.EventHandler(this.renewDrivingLicenceToolStripMenuItem_Click);
            // 
            // refreshToolStripMenuItem
            // 
            this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
            this.refreshToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.refreshToolStripMenuItem.Text = "Refresh";
            this.refreshToolStripMenuItem.Click += new System.EventHandler(this.refreshToolStripMenuItem_Click);
            // 
            // replacmentForDamegedToolStripMenuItem
            // 
            this.replacmentForDamegedToolStripMenuItem.Name = "replacmentForDamegedToolStripMenuItem";
            this.replacmentForDamegedToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.replacmentForDamegedToolStripMenuItem.Text = "Replacment For Dameged ";
            this.replacmentForDamegedToolStripMenuItem.Click += new System.EventHandler(this.replacmentForDamegedToolStripMenuItem_Click_1);
            // 
            // replacmentForLostToolStripMenuItem
            // 
            this.replacmentForLostToolStripMenuItem.Name = "replacmentForLostToolStripMenuItem";
            this.replacmentForLostToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.replacmentForLostToolStripMenuItem.Text = "Replacment For Lost ";
            this.replacmentForLostToolStripMenuItem.Click += new System.EventHandler(this.replacmentForLostToolStripMenuItem_Click);
            // 
            // detainedLicenceToolStripMenuItem
            // 
            this.detainedLicenceToolStripMenuItem.Name = "detainedLicenceToolStripMenuItem";
            this.detainedLicenceToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.detainedLicenceToolStripMenuItem.Text = "Detained Licence";
            this.detainedLicenceToolStripMenuItem.Click += new System.EventHandler(this.detainedLicenceToolStripMenuItem_Click);
            // 
            // relaeasLicenceToolStripMenuItem
            // 
            this.relaeasLicenceToolStripMenuItem.Name = "relaeasLicenceToolStripMenuItem";
            this.relaeasLicenceToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.relaeasLicenceToolStripMenuItem.Text = "Relaeas Licence";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DVLI.Properties.Resources.shopping;
            this.pictureBox1.Location = new System.Drawing.Point(351, 34);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(211, 191);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // FormViewLicenceHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(963, 675);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "FormViewLicenceHistory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormViewLicenceHistory";
            this.Load += new System.EventHandler(this.FormViewLicenceHistory_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem viewLicenceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem renewDrivingLicenceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem replacmentForDamegedToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem replacmentForLostToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem detainedLicenceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relaeasLicenceToolStripMenuItem;
    }
}