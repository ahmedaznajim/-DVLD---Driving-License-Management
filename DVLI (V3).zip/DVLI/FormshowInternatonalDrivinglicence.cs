﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Presentation;

namespace DVLI
{
    public partial class FormshowInternatonalDrivinglicence : Form
    {
        public FormshowInternatonalDrivinglicence()
        {
            InitializeComponent();
           dataGridView1.DataSource= ClsApplication.GetInternationalApplications();
        }

        private void FormshowInternatonalDrivinglicence_Load(object sender, EventArgs e)
        {

        }

        private void deactivateLicenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ClsLicense.DeactivateInternationalDrivingLicence(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value)))
            {
                dataGridView1.DataSource = ClsApplication.GetInternationalApplications();
                MessageBox.Show("done");
            }
            else
            {
                MessageBox.Show("Faild");

            }
        }
    }
}
