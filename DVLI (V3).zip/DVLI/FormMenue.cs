﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business;
using DVLI.Driver;
using DVLI.Licence;
using Presentation;

namespace DVLI
{
    public partial class FormMenue : Form
    {
        public string UserName {  get; set; }
        public FormMenue(string UserName)
        {
            InitializeComponent();
            this.UserName = UserName;
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {

        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            peopleForm f=new peopleForm();
            f.ShowDialog();
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripButton1_Click_2(object sender, EventArgs e)
        {
            peopleForm f = new peopleForm();
            f.ShowDialog();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {

        }

        private void currentUserInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
         DataTable dt=ClsUsers.FindUserInInfoByUserName(ClassCurrentUser.userName);
           

            DataRow dr = dt.Rows[0];
            ClscurrentUser.CurrentUserID = Convert.ToInt32(dr[0]);
            ClscurrentUser.FName = Convert.ToString(dr[6]);
            ClscurrentUser.SName = Convert.ToString(dr[7]);

            FormShowUserInfo formShowUserInfo =new FormShowUserInfo(Convert.ToInt32(dr[0]), Convert.ToString(dr[6]), Convert.ToString(dr[7]), Convert.ToString(dr[8]),
                Convert.ToString(dr[9]), Convert.ToString(dr[10]), Convert.ToString(dr[11]), Convert.ToInt32(dr[12]), Convert.ToString(dr[13]),
                Convert.ToString(dr[14]), Convert.ToString(dr[15]), Convert.ToInt32(dr[16]), Convert.ToString(dr[17]));

         formShowUserInfo.ShowDialog();

           
        }

        private void ApplicationsToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void PeopleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            peopleForm f = new peopleForm();
            f.ShowDialog();
        }

        private void signOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormLogIn formLogIn = new FormLogIn();
          this.Hide();
            formLogIn.ShowDialog();
            this.Close();
        }

        private void UsersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormUsers formUsers = new FormUsers();
            formUsers.ShowDialog();
        }

        private void manageApplicationsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void manageApplicationTypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormApplicationsType formApplicationsType = new FormApplicationsType();
            formApplicationsType.ShowDialog();
        }

        private void manageTestTypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTestType formTestType = new FormTestType();
            formTestType.ShowDialog();
        }

        private void retakeTestToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void localLicenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormNewLocalDrivingLicience formNewLocalDrivingLicience=new FormNewLocalDrivingLicience(UserName);
            formNewLocalDrivingLicience.ShowDialog();
        }

        private void internationalDrivingLicenceApplicationsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormLocalDrivingLicenceApplications form=new FormLocalDrivingLicenceApplications();
            form.ShowDialog();
        }

        private void localDrivingLicenceApplicationsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormshowInternatonalDrivinglicence formshow=new FormshowInternatonalDrivinglicence();
            formshow.ShowDialog();

        }

        private void drivingLicenceServesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void DriversToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormDriver formDriver = new FormDriver();
            formDriver.ShowDialog();
        }

        private void internationalLicenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormInternationalDrivingLicence formInternationalDrivingLicence = new FormInternationalDrivingLicence();
            formInternationalDrivingLicence.ShowDialog();
        }

        private void renewDrivingLicenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormRenew formRenew = new FormRenew();
            formRenew.ShowDialog();
        }

        private void replacmentForLostOrDamegedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormReplacForLost formReplacForLost = new FormReplacForLost();
            formReplacForLost.ShowDialog();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
           FormReplacForDamage formReplacForDamage = new FormReplacForDamage();
            formReplacForDamage.ShowDialog();
        }

        private void detainLicenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormDetainLicence formDetainLicence = new FormDetainLicence();
            formDetainLicence.ShowDialog();
        }

        private void relaeasDetainedLicenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormRelease formRelease = new FormRelease();
            formRelease.ShowDialog();
        }

        private void registerACarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void registerANewCarToolStripMenuItem_Click(object sender, EventArgs e)
        {

            FormRegisterAcarF formRegisterAcarF = new FormRegisterAcarF();
            formRegisterAcarF.ShowDialog();
        }

        private void reRegisterACarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormReRegisterACar formReRegisterACar = new FormReRegisterACar();
            formReRegisterACar.ShowDialog();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
