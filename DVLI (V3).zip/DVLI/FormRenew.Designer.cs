﻿namespace DVLI
{
    partial class FormRenew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.userControlLCImfo1 = new DVLI.Licence.UserControlLCImfo();
            this.buttonRenew = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // userControlLCImfo1
            // 
            this.userControlLCImfo1.ExpirationDateText = "[????]";
            this.userControlLCImfo1.Location = new System.Drawing.Point(12, 12);
            this.userControlLCImfo1.Name = "userControlLCImfo1";
            this.userControlLCImfo1.Size = new System.Drawing.Size(1075, 429);
            this.userControlLCImfo1.TabIndex = 0;
            this.userControlLCImfo1.Load += new System.EventHandler(this.userControlLCImfo1_Load);
            // 
            // buttonRenew
            // 
            this.buttonRenew.Location = new System.Drawing.Point(958, 499);
            this.buttonRenew.Name = "buttonRenew";
            this.buttonRenew.Size = new System.Drawing.Size(129, 23);
            this.buttonRenew.TabIndex = 1;
            this.buttonRenew.Text = "Renew";
            this.buttonRenew.UseVisualStyleBackColor = true;
            this.buttonRenew.Click += new System.EventHandler(this.buttonRenew_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(813, 499);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(129, 23);
            this.buttonCancel.TabIndex = 2;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // FormRenew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1105, 558);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonRenew);
            this.Controls.Add(this.userControlLCImfo1);
            this.Name = "FormRenew";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormRenew";
            this.Load += new System.EventHandler(this.FormRenew_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Licence.UserControlLCImfo userControlLCImfo1;
        private System.Windows.Forms.Button buttonRenew;
        private System.Windows.Forms.Button buttonCancel;
    }
}