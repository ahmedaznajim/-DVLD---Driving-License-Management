﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Presentation;

namespace DVLI.Licence
{
    public partial class FormViewDrivingLicenceInfromations : Form
    {
        DataTable dt;
        DataRow dr;
        public FormViewDrivingLicenceInfromations(DataTable dt)
        {
            InitializeComponent();
            this.dt = dt;
            dr=dt.Rows[0];
            lblClass.Text = Convert.ToString(dr[1]);
            lblFullName.Text = Convert.ToString(dr[2])+" "+ Convert.ToString(dr[3]);
            lblLicenseID.Text = Convert.ToString(dr[4]);
lblNationalNo.Text= Convert.ToString(dr[5]);
            lblGendor.Text = Convert.ToString(dr[6]);
            lblIssueDate.Text = Convert.ToString(dr[7]);
            lblIssueReason.Text = Convert.ToString(dr[8]);
            lblNotes.Text = Convert.ToString(dr[9]);
            lblIsActive.Text = Convert.ToString(dr[10]);
            lblDateOfBirth.Text = Convert.ToString(dr[11]);
            lblDriverID.Text = Convert.ToString(dr[12]);
            lblExpirationDate.Text = Convert.ToString(dr[13]);
            lblIsDetained.Text = ClsLicense.IsLicenceDetained(Convert.ToInt32(dr[4]));



        }

        private void FormViewDrivingLicenceInfromations_Load(object sender, EventArgs e)
        {

        }

        private void buttonExist_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Close();
        }

        private void lblExpirationDate_Click(object sender, EventArgs e)
        {

        }
    }
}
