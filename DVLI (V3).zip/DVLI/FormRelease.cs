﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DVLI.Licence;
using Presentation;

namespace DVLI
{
    public partial class FormRelease : Form
    {
        DataTable DTInfo;
        public FormRelease()
        {
            InitializeComponent();
            
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Close();
        }

        private void buttonRelease_Click(object sender, EventArgs e)
        {
            DataTable dt2 = ClsUsers.SerchByUserName(ClassCurrentUser.userName);
            DataRow dr2 = dt2.Rows[0];
            DateTime dt = userControlLCImfo1.ExDate;
            DTInfo = ClsLicense.getDetainInfo(Convert.ToInt32(userControlLCImfo1.dt.Rows[0][0]));
            if (userControlLCImfo1.IsActive == 0)
            {
                MessageBox.Show("cant Detain an inactive Licence");
                return;
            }
            if (ClsLicense.IsLicenceDetained(Convert.ToInt32(userControlLCImfo1.dt.Rows[0][0])) == "No")
            {
                MessageBox.Show("The License is already Released");
                return;
            }
            int ApplicationID = ClsApplication.AddNewApplication(Convert.ToInt32(userControlLCImfo1.dt.Rows[0][14]), DateTime.Now, 5, 1, DateTime.Now, 15, Convert.ToInt32(dr2[0]));
            if (ApplicationID == -1)
            {

                MessageBox.Show("Faild");
            }
            else {

                if (ClsLicense.ReleaseLicenec(Convert.ToInt32(userControlLCImfo1.dt.Rows[0][0]), Convert.ToDateTime(DTInfo.Rows[0][2]), Convert.ToInt32(DTInfo.Rows[0][3]), Convert.ToInt32(DTInfo.Rows[0][4]), 1, DateTime.Now, Convert.ToInt32(dr2[0]), ApplicationID) == false)
                {
                    MessageBox.Show("Faild");
                }
                else
                {
                    MessageBox.Show("Done");

                    this.Hide();
                    this.Close();
                    FormViewDrivingLicenceInfromations form = new FormViewDrivingLicenceInfromations(userControlLCImfo1.dt);
                    form.ShowDialog();
                }
            }
        }

        private void FormRelease_Load(object sender, EventArgs e)
        {

        }
    }
}
