﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DVLI.Licence;
using Presentation;

namespace DVLI
{
    public partial class FormRenew : Form
    {
        public FormRenew()
        {
            InitializeComponent();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Close();
        }

        private void buttonRenew_Click(object sender, EventArgs e)
        {
            DateTime dt = userControlLCImfo1.ExDate;
            if (userControlLCImfo1.ExDate > DateTime.Now)
            {
                MessageBox.Show("The License is not Expired");
                return;
            }
            DataRow dr = userControlLCImfo1.dt.Rows[0];
            DataTable dt2= ClsUsers.SerchByUserName(ClassCurrentUser.userName);
            DataRow dr2 = dt2.Rows[0];
            int ApplicationID = ClsApplication.AddNewApplication(Convert.ToInt32(dr[14]), DateTime.Now, 2, 1, DateTime.Now, 5, Convert.ToInt32(dr2[0]));
            if (ApplicationID == -1)
            {

                MessageBox.Show("Faild");
            }
            else
            {
                if (ClsLicense.DeactivateLocalDrivingLicence(Convert.ToInt32(dr[0])))
                {
                    int LLDId = ClsLicense.AddNewLicence(ApplicationID, 
                        Convert.ToInt32(dr[12])
                        , Convert.ToInt32(dr[15]),
                        DateTime.Now,
                        Convert.ToDateTime(dr[13]),
                        " ",
                        20,
                        1,
                        2,
                        Convert.ToInt32(dr2[0]));
                    if (LLDId == -1)
                    {
                        MessageBox.Show("Faild");

                    }
                    else
                    {

                        MessageBox.Show("Done");
                        DataTable dt1 = ClsLicense.ShowLicenceInfo(LLDId);
                        FormViewDrivingLicenceInfromations form = new FormViewDrivingLicenceInfromations(dt1);
                        form.ShowDialog();

                    }


                }



            }


        }

        private void userControlLCImfo1_Load(object sender, EventArgs e)
        {

        }

        private void FormRenew_Load(object sender, EventArgs e)
        {

        }
    }
}
