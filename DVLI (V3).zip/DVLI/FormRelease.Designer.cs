﻿namespace DVLI
{
    partial class FormRelease
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.userControlLCImfo1 = new DVLI.Licence.UserControlLCImfo();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonRelease = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labelFine = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // userControlLCImfo1
            // 
            this.userControlLCImfo1.ExpirationDateText = "[????]";
            this.userControlLCImfo1.Location = new System.Drawing.Point(12, 12);
            this.userControlLCImfo1.Name = "userControlLCImfo1";
            this.userControlLCImfo1.Size = new System.Drawing.Size(1075, 443);
            this.userControlLCImfo1.TabIndex = 0;
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(755, 486);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(129, 23);
            this.buttonCancel.TabIndex = 4;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonRelease
            // 
            this.buttonRelease.Location = new System.Drawing.Point(913, 486);
            this.buttonRelease.Name = "buttonRelease";
            this.buttonRelease.Size = new System.Drawing.Size(129, 23);
            this.buttonRelease.TabIndex = 3;
            this.buttonRelease.Text = "Release";
            this.buttonRelease.UseVisualStyleBackColor = true;
            this.buttonRelease.Click += new System.EventHandler(this.buttonRelease_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(432, 374);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 24);
            this.label1.TabIndex = 5;
            this.label1.Text = "Detention Fine";
            // 
            // labelFine
            // 
            this.labelFine.AutoSize = true;
            this.labelFine.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFine.Location = new System.Drawing.Point(631, 374);
            this.labelFine.Name = "labelFine";
            this.labelFine.Size = new System.Drawing.Size(43, 24);
            this.labelFine.TabIndex = 6;
            this.labelFine.Text = "???";
            // 
            // FormRelease
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1110, 558);
            this.Controls.Add(this.labelFine);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonRelease);
            this.Controls.Add(this.userControlLCImfo1);
            this.Name = "FormRelease";
            this.Text = "FormRelease";
            this.Load += new System.EventHandler(this.FormRelease_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Licence.UserControlLCImfo userControlLCImfo1;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button buttonRelease;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelFine;
    }
}