﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business;
using Presentation;

namespace DVLI
{
    public partial class FormAddUser : Form
    {
        DataTable dt = new DataTable();
        DataRow row1;

        public FormAddUser()
        {
            InitializeComponent();
            dt = Person.GetPplInfo();
            foreach (DataRow row in dt.Rows)
            {
                comboBox1.Items.Add(row[3].ToString());


            }
        }

        private void FormAddUser_Load(object sender, EventArgs e)
        {

        }
        
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            row1=dt.Rows[comboBox1.SelectedIndex];
            DataTable dt1 = ClsUsers.SerchByPersonID(Convert.ToInt32(row1[0]));

            if (dt1 != null && dt1.Rows.Count > 0)
            {
                MessageBox.Show("This User is already exist");
            }
            else
            {
                if (ClsUsers.AddNewUser(Convert.ToInt32(row1[0]), textBoxUserName.Text, textBoxPassword.Text, 1) == -1)
                {
                    MessageBox.Show("Faild");
                }
                else
                {

                    MessageBox.Show("Done");
                    this.Close();
                }
            }
        }
    }
}
