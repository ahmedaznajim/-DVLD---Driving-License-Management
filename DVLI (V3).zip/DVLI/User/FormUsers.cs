﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Presentation;

namespace DVLI
{
    public partial class FormUsers : Form
    {
        public FormUsers()
        {
            InitializeComponent();
            dataGridView1.DataSource = ClsUsers.GetAllUsrers();
        }

        private void FormUsers_Load(object sender, EventArgs e)
        {

        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                FormUpdateUser f = new FormUpdateUser(
                     Convert.ToInt32(selectedRow.Cells[0].Value),
                    Convert.ToInt32(selectedRow.Cells[1].Value),
                    Convert.ToString(selectedRow.Cells[2].Value),
                    Convert.ToString(selectedRow.Cells[3].Value),
                    Convert.ToInt32(selectedRow.Cells[4].Value)


                );

                f.ShowDialog();
            }
        }

        private void AddPplbtn_Click(object sender, EventArgs e)
        {
          
            
                FormAddUser formAddUser = new FormAddUser();
                formAddUser.ShowDialog();
            
         

        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ClsUsers.GetAllUsrers();
        }

        private void textBoxSerch_TextChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                try
                {
                    dataGridView1.DataSource = ClsUsers.SerchByUserID(Convert.ToInt32(textBoxSerch.Text));

                }
                catch { }
            }

                if (comboBox1.SelectedIndex == 1)
                {
                    try
                    {
                        dataGridView1.DataSource = ClsUsers.SerchByUserName(Convert.ToString(textBoxSerch.Text));

                    }
                    catch { }
                }

            if (comboBox1.SelectedIndex == 2)
            {
                try
                {
                    dataGridView1.DataSource = ClsUsers.SerchByPersonID(Convert.ToInt32(textBoxSerch.Text));

                }
                catch { }
            }

            if (textBoxSerch.Text == "") {
                dataGridView1.DataSource = ClsUsers.GetAllUsrers();

            }
            }
        }
    }
