﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business;
using DVLI.Properties;
using Presentation;

namespace DVLI
{
    public partial class FormReRegisterACar : Form
    {
        DataTable dt = new DataTable();
        DataRow row1;
        public DataTable dt1 = new DataTable();
        DataRow row2;
        DataTable dt3 = new DataTable();
        DataRow row3;
        public int id = 0;
        DataTable dtt;
        public FormReRegisterACar()
        {
            InitializeComponent();
            try
            {

                dt = ClsCountry.GetCountries();
                comboBox2.Enabled = false;

                foreach (DataRow row in dt.Rows)
                {
                    comboBox2.Items.Add(row[1].ToString());


                }
                dt3 = ClsLicense.getLicensesClasses();



            }
            catch { }
        }

        private void FormReRegisterACar_Load(object sender, EventArgs e) {
           


        }

        private void buttonSerch_Click(object sender, EventArgs e)
        {
            try
            {
                string i = Convert.ToString(textBox1.Text);
                dt1 = Person.SerchByNationalNo(i);
                row2 = dt1.Rows[0];
                labelId.Text = Convert.ToString(row2[0]);
                id = Convert.ToInt32(row2[0]);
                labelNo.Text = Convert.ToString(row2[1]);
                labelfname.Text = Convert.ToString(row2[2]);
                labelsname.Text = Convert.ToString(row2[3]);
                labeltname.Text = Convert.ToString(row2[4]);
                labeltname.Text = Convert.ToString(row2[5]);
                labelBirth.Text = Convert.ToString(row2[6]);
                if (Convert.ToInt32(row2[7]) == 0)
                {
                    labelGender.Text = "Male";
                }
                if (Convert.ToInt32(row2[7]) == 1)
                {
                    labelGender.Text = "Female";
                }
                labelAdress.Text = Convert.ToString(row2[8]);

                labelphone.Text = Convert.ToString(row2[9]);
                labelEmail.Text = Convert.ToString(row2[10]);
                comboBox2.SelectedIndex = Convert.ToInt32(row2[11]) - 1;
                dtt = ClsCar.GetUnregisterdCars(Convert.ToInt32(labelId.Text));
                foreach (DataRow row1 in dtt.Rows)
                {
                    comboBox1.Items.Add(row1[3].ToString());
                }
                try
                {
                    pictureBox1.Image = Image.FromFile(Convert.ToString(row2[12]));
                }
                catch { }



            }
            catch { }








            if (textBox1.Text == "")
            {


                labelId.Text =
                labelNo.Text =
                labelfname.Text = "";
                labelsname.Text = "";
                labeltname.Text = "";
                labeltname.Text = "";
                labelBirth.Text = "";

                labelGender.Text = "";





                labelAdress.Text = "";

                labelphone.Text = "";
                labelEmail.Text = "";
                comboBox2.SelectedIndex = 89;

                pictureBox1.Image = Resources.user;
                id = 0;





            }



        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Close();   
            
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            DataTable dt2 = ClsUsers.SerchByUserName(ClassCurrentUser.userName);
            DataRow dr2 = dt2.Rows[0];
            int ApplicationID = ClsApplication.AddNewApplication(Convert.ToInt32(labelId.Text), DateTime.Now, 1008, 1, DateTime.Now, 15, Convert.ToInt32(dr2[0]));
            if (ApplicationID == -1)
            {

                MessageBox.Show("Faild");
            }
            else
            {
                DataTable dt = ClsUsers.SerchByPersonID(Convert.ToInt32(labelId.Text));
          

                if (ClsCar.ReRegister(Convert.ToInt32( dtt.Rows[0][0])) == false)
                {
                    MessageBox.Show("Faild");
                }
               
                else
                {
                    MessageBox.Show("Done");

                    this.Hide();
                    this.Close();
                    FormShowCarLicence form = new FormShowCarLicence(Convert.ToInt32(dtt.Rows[0][0]));
                    form.ShowDialog();




                }



            }
        }
    }
}
