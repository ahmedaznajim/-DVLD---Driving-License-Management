﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business;
using DVLI.Licence;
using DVLI.Test;
using Presentation;

namespace DVLI
{
    public partial class FormLocalDrivingLicenceApplications : Form
    {
        public FormLocalDrivingLicenceApplications()
        {
            InitializeComponent();
            dataGridView1.DataSource = ClsApplication.GetLocalApplications();
        }

        private void FormLocalDrivingLicenceApplications_Load(object sender, EventArgs e)
        {

        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {


            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];


                if (ClsApplication.CancelLocalLicenceApplication(Convert.ToInt32(selectedRow.Cells[1].Value)))
                {

                    MessageBox.Show("Done");
                    dataGridView1.DataSource = ClsApplication.GetLocalApplications();
                }
                else
                {
                    MessageBox.Show("Faild");
                    dataGridView1.DataSource = ClsApplication.GetLocalApplications();


                }





            }
        }

        private void deleteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                if (ClsApplication.DeleteLocalLicencesApplication(Convert.ToInt32(selectedRow.Cells[2].Value)))
                {
                    MessageBox.Show("Deleted");
                    dataGridView1.DataSource = ClsApplication.GetLocalApplications();
                }
                else
                {
                    MessageBox.Show("Faild");
                    dataGridView1.DataSource = ClsApplication.GetLocalApplications();

                }



            }
        }

        private void schdualAVisionTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow;
            FormVisionTest formVision;
            if (dataGridView1.SelectedRows.Count > 0)
            {
                selectedRow = dataGridView1.SelectedRows[0];



                formVision = new FormVisionTest(Convert.ToInt32(selectedRow.Cells[3].Value));
                formVision.ShowDialog();

            }










        }

        private void sechudalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            schdualAVisionTestToolStripMenuItem.Enabled = true;
            schdualAWrittenTestToolStripMenuItem.Enabled = false;
            schdualAStreetTestToolStripMenuItem.Enabled = false;



            try
            {
                if (Convert.ToString(dataGridView1.SelectedRows[0].Cells[8].Value) == "Completed" || (Convert.ToString(dataGridView1.SelectedRows[0].Cells[8].Value) == "Canceled"))
                {
                    schdualAVisionTestToolStripMenuItem.Enabled = false;
                    schdualAWrittenTestToolStripMenuItem.Enabled = false;
                    schdualAStreetTestToolStripMenuItem.Enabled = false;
                }
                else
                {
                    if (Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[9].Value) == 1)
                    {
                        schdualAVisionTestToolStripMenuItem.Enabled = false;
                        schdualAWrittenTestToolStripMenuItem.Enabled = true;
                        schdualAStreetTestToolStripMenuItem.Enabled = false;
                    }

                    if (Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[9].Value) == 2)
                    {
                        schdualAVisionTestToolStripMenuItem.Enabled = false;
                        schdualAWrittenTestToolStripMenuItem.Enabled = false;
                        schdualAStreetTestToolStripMenuItem.Enabled = true;
                    }
                    if (Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[9].Value) == 3)
                    {
                        schdualAVisionTestToolStripMenuItem.Enabled = false;
                        schdualAWrittenTestToolStripMenuItem.Enabled = false;
                        schdualAStreetTestToolStripMenuItem.Enabled = false;
                    }
                }



            }
            catch { }










        }

        private void schdualAWrittenTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow;
            FormWrittenTest formWrittenTest;
            if (dataGridView1.SelectedRows.Count > 0)
            {
                selectedRow = dataGridView1.SelectedRows[0];



                formWrittenTest = new FormWrittenTest(Convert.ToInt32(selectedRow.Cells[2].Value), 1);
                formWrittenTest.ShowDialog();
                dataGridView1.DataSource = ClsApplication.GetLocalApplications();

            }
        }

        private void schdualAStreetTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow;
            FormWrittenTest formWrittenTest;
            if (dataGridView1.SelectedRows.Count > 0)
            {
                selectedRow = dataGridView1.SelectedRows[0];



                formWrittenTest = new FormWrittenTest(Convert.ToInt32(selectedRow.Cells[2].Value), 2);
                formWrittenTest.ShowDialog();
                dataGridView1.DataSource = ClsApplication.GetLocalApplications();

            }
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ClsApplication.GetLocalApplications();
        }

        private void completeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];


                if (ClsApplication.SetStatuesToComplete(Convert.ToInt32(selectedRow.Cells[0].Value)))
                {

                    MessageBox.Show("Done");
                    dataGridView1.DataSource = ClsApplication.GetLocalApplications();
                }
                else
                {
                    MessageBox.Show("Faild");
                    dataGridView1.DataSource = ClsApplication.GetLocalApplications();


                }





            }
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            try
            {
                issueALicenenceToolStripMenuItem.Enabled = false;
                if ((Convert.ToString(dataGridView1.SelectedRows[0].Cells[8].Value) == "Completed"))
                {
                    issueALicenenceToolStripMenuItem.Enabled = true;

                }
            }
            catch { }
        }

        private void issueALicenenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (ClsLicense.IsLicenceExist(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[2].Value), Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[3].Value)))
                {
                    MessageBox.Show("This User Already has a licence");

                }
                else
                {
                    int DriverId = ClsDriver.IsDriverExists(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[1].Value));

                    if (DriverId == -1)
                    {
                        DriverId = ClsDriver.AddNewDriver(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[1].Value), 1, DateTime.Now);
                    }
                    else
                    {


                        int appID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[2].Value);
                        int LicenecClassID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[3].Value);
                        int paidFees = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[10].Value);
                        int LicenceId = ClsLicense.AddNewLicence(appID, DriverId, LicenecClassID
                            , DateTime.Now, ClsLicense.getLicenceclassExpireDate(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[3].Value)), "   ", paidFees, 1, 1, 1);
                        DataTable dt = ClsLicense.ShowLicenceInfo(LicenceId);
                        FormViewDrivingLicenceInfromations form = new FormViewDrivingLicenceInfromations(dt);
                        form.ShowDialog();
                        dataGridView1.DataSource = ClsApplication.GetLocalApplications();
                    }
                }
            }
            catch
            { }

        }

    



        private void textBoxSerch_TextChanged(object sender, EventArgs e)
        {

            if (comboBox1.SelectedIndex == 0)
            {


                dataGridView1.DataSource = ClsApplication.GetLocalApplications();


            }
            if (comboBox1.SelectedIndex == 1)
            {


                dataGridView1.DataSource = ClsLicense.SerchLocalByLastName(textBoxSerch.Text);


            }

            if (comboBox1.SelectedIndex == 2)
            {
                try
                {
                    int i = Convert.ToInt32(textBoxSerch.Text);
                    dataGridView1.DataSource = ClsLicense.SerchLocaDLByID(i);
                }
                catch { }

            }
            if (comboBox1.SelectedIndex == 3)
            {
                try
                {
                    string i = Convert.ToString(textBoxSerch.Text);
                    dataGridView1.DataSource = ClsLicense.SerchLocalByNationalNo(i);
                }
                catch { }

            }

            if (textBoxSerch.Text == "")
            {
                dataGridView1.DataSource = ClsApplication.GetLocalApplications();


            }
        }

        private void renewDrivingLicenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataTable dt =ClsApplication.GetLocalApplications2();
            DataRow dataRow = dt.Rows[Convert.ToInt32( dataGridView1.Rows[0].Cells[0].Value)];
            //if (ClsApplication.AddNewApplication(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value), DateTime.Now, 2, 1, DateTime.Now, 5, 1) == -1)
            //{

            //    MessageBox.Show("Faild");
            //}
            //else
            //{
            //    if (ClsLicense.DeactivateLocalDrivingLicence(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[11].Value)))
            //    {
            //        int LLDId = ClsLicense.AddNewLicence(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[1].Value), Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[12].Value)
            //            , Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[2].Value), DateTime.Now, ClsLicense.getLicenceclassExpireDate(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[2].Value)),
            //            " ", 20, 1, 2, 1);
            //        if (LLDId == -1)
            //        {
            //            MessageBox.Show("Faild");

            //        }
            //        else
            //        {
            //            if (ClsApplication.AddNewLocalApplication(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[1].Value), Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[2].Value)) == -1)
            //            {
            //                MessageBox.Show("Faild");
            //            }
            //            else
            //            {
            //                MessageBox.Show("Done");
            //                dataGridView1.DataSource = ClsApplication.GetLocalApplications();
            //            }

            //        }

            if (ClsApplication.AddNewApplication(Convert.ToInt32(dataRow[0]), DateTime.Now, 2, 1, DateTime.Now, 5, 1) == -1)
            {

                MessageBox.Show("Faild");
            }
            else
            {
                if (ClsLicense.DeactivateLocalDrivingLicence(Convert.ToInt32(dataRow[11])))
                {
                    int LLDId = ClsLicense.AddNewLicence(Convert.ToInt32(dataRow[1]), Convert.ToInt32(dataRow[12])
                        , Convert.ToInt32(dataRow[2]), DateTime.Now, ClsLicense.getLicenceclassExpireDate(Convert.ToInt32(dataRow[2])),
                        " ", 20, 1, 2, 1);
                    if (LLDId == -1)
                    {
                        MessageBox.Show("Faild");

                    }
                    else
                    {

                        MessageBox.Show("Done");
                        dataGridView1.DataSource = ClsApplication.GetLocalApplications();
                    }
                        

                    }



                }
            }

        private void replacmentForLostOrDamegedToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
    }

