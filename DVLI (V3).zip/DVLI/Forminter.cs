﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Presentation;

namespace DVLI
{
    public partial class Forminter : Form
    {
        public Forminter()
        {
            InitializeComponent();
            dataGridView1.DataSource=ClsDriver.GetlDriverttoCreateInternatiomalDrivingLicence();
        }

        private void Forminter_Load(object sender, EventArgs e)
        {

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            try
            {
                if (Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[6].Value) == 0)
                {
                    createAnInternationalDrivingLicenceToolStripMenuItem.Enabled = false;


                }
                if (Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[6].Value) == 1)
                {
                    createAnInternationalDrivingLicenceToolStripMenuItem.Enabled = true;


                }
            }
            catch { }
        }

        private void createAnInternationalDrivingLicenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ClsLicense.IsInternationalLicenceExist(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[2].Value)))
            {
                MessageBox.Show("The Licence is already Exist");
            }
            else
            {
                if (ClsLicense.AddNewInternationalLicence(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value), Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[1].Value), Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[2].Value)
                    , DateTime.Now, ClsLicense.getLicenceclassExpireDate(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[7].Value)), 1, 1) == -1)
                {
                    MessageBox.Show("Faild");

                }
                else
                {
                    MessageBox.Show("Done");
                }

            }
        }

        private void deactivateLicenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }
    }
}
