﻿namespace DVLI
{
    partial class UserControlShowCarLicence
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelEDate = new System.Windows.Forms.Label();
            this.labelSDate = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelYear = new System.Windows.Forms.Label();
            this.labelDoors = new System.Windows.Forms.Label();
            this.labelFuleType = new System.Windows.Forms.Label();
            this.labelEngine = new System.Windows.Forms.Label();
            this.labelCarName = new System.Windows.Forms.Label();
            this.labelColor = new System.Windows.Forms.Label();
            this.labelVIN = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.labelFname = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelEDate
            // 
            this.labelEDate.AutoSize = true;
            this.labelEDate.Location = new System.Drawing.Point(488, 167);
            this.labelEDate.Name = "labelEDate";
            this.labelEDate.Size = new System.Drawing.Size(74, 17);
            this.labelEDate.TabIndex = 50;
            this.labelEDate.Text = "??-??-????";
            // 
            // labelSDate
            // 
            this.labelSDate.AutoSize = true;
            this.labelSDate.Location = new System.Drawing.Point(488, 125);
            this.labelSDate.Name = "labelSDate";
            this.labelSDate.Size = new System.Drawing.Size(74, 17);
            this.labelSDate.TabIndex = 49;
            this.labelSDate.Text = "??-??-????";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 125);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 17);
            this.label11.TabIndex = 47;
            this.label11.Text = "Year";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(381, 169);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 17);
            this.label5.TabIndex = 40;
            this.label5.Text = "End Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(381, 122);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 17);
            this.label6.TabIndex = 39;
            this.label6.Text = "Start Date";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(381, 78);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 17);
            this.label7.TabIndex = 38;
            this.label7.Text = "Color";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(381, 31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 17);
            this.label8.TabIndex = 37;
            this.label8.Text = "VIN";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 266);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 17);
            this.label4.TabIndex = 36;
            this.label4.Text = "Number of Doors";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 219);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 17);
            this.label3.TabIndex = 35;
            this.label3.Text = "Fule Type";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 172);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 17);
            this.label2.TabIndex = 34;
            this.label2.Text = "Engine";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 17);
            this.label1.TabIndex = 33;
            this.label1.Text = "Car Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // labelYear
            // 
            this.labelYear.AutoSize = true;
            this.labelYear.Location = new System.Drawing.Point(147, 125);
            this.labelYear.Name = "labelYear";
            this.labelYear.Size = new System.Drawing.Size(35, 17);
            this.labelYear.TabIndex = 57;
            this.labelYear.Text = "Year";
            this.labelYear.Click += new System.EventHandler(this.labelYear_Click);
            // 
            // labelDoors
            // 
            this.labelDoors.AutoSize = true;
            this.labelDoors.Location = new System.Drawing.Point(147, 266);
            this.labelDoors.Name = "labelDoors";
            this.labelDoors.Size = new System.Drawing.Size(114, 17);
            this.labelDoors.TabIndex = 56;
            this.labelDoors.Text = "Number of Doors";
            this.labelDoors.Click += new System.EventHandler(this.labelDoors_Click);
            // 
            // labelFuleType
            // 
            this.labelFuleType.AutoSize = true;
            this.labelFuleType.Location = new System.Drawing.Point(147, 219);
            this.labelFuleType.Name = "labelFuleType";
            this.labelFuleType.Size = new System.Drawing.Size(67, 17);
            this.labelFuleType.TabIndex = 55;
            this.labelFuleType.Text = "Fule Type";
            this.labelFuleType.Click += new System.EventHandler(this.labelFuleType_Click);
            // 
            // labelEngine
            // 
            this.labelEngine.AutoSize = true;
            this.labelEngine.Location = new System.Drawing.Point(147, 172);
            this.labelEngine.Name = "labelEngine";
            this.labelEngine.Size = new System.Drawing.Size(49, 17);
            this.labelEngine.TabIndex = 54;
            this.labelEngine.Text = "Engine";
            this.labelEngine.Click += new System.EventHandler(this.labelEngine_Click);
            // 
            // labelCarName
            // 
            this.labelCarName.AutoSize = true;
            this.labelCarName.Location = new System.Drawing.Point(147, 78);
            this.labelCarName.Name = "labelCarName";
            this.labelCarName.Size = new System.Drawing.Size(68, 17);
            this.labelCarName.TabIndex = 53;
            this.labelCarName.Text = "Car Name";
            this.labelCarName.Click += new System.EventHandler(this.labelCarName_Click);
            // 
            // labelColor
            // 
            this.labelColor.AutoSize = true;
            this.labelColor.Location = new System.Drawing.Point(488, 78);
            this.labelColor.Name = "labelColor";
            this.labelColor.Size = new System.Drawing.Size(40, 17);
            this.labelColor.TabIndex = 59;
            this.labelColor.Text = "Color";
            // 
            // labelVIN
            // 
            this.labelVIN.AutoSize = true;
            this.labelVIN.Location = new System.Drawing.Point(488, 31);
            this.labelVIN.Name = "labelVIN";
            this.labelVIN.Size = new System.Drawing.Size(29, 17);
            this.labelVIN.TabIndex = 58;
            this.labelVIN.Text = "VIN";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 31);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 17);
            this.label10.TabIndex = 60;
            this.label10.Text = "Full Name";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // labelFname
            // 
            this.labelFname.AutoSize = true;
            this.labelFname.Location = new System.Drawing.Point(147, 31);
            this.labelFname.Name = "labelFname";
            this.labelFname.Size = new System.Drawing.Size(43, 17);
            this.labelFname.TabIndex = 62;
            this.labelFname.Text = "?????";
            // 
            // UserControlShowCarLicence
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.labelFname);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.labelColor);
            this.Controls.Add(this.labelVIN);
            this.Controls.Add(this.labelYear);
            this.Controls.Add(this.labelDoors);
            this.Controls.Add(this.labelFuleType);
            this.Controls.Add(this.labelEngine);
            this.Controls.Add(this.labelCarName);
            this.Controls.Add(this.labelEDate);
            this.Controls.Add(this.labelSDate);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "UserControlShowCarLicence";
            this.Size = new System.Drawing.Size(566, 316);
            this.Load += new System.EventHandler(this.UserControlShowCarLicence_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelEDate;
        private System.Windows.Forms.Label labelSDate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelYear;
        private System.Windows.Forms.Label labelDoors;
        private System.Windows.Forms.Label labelFuleType;
        private System.Windows.Forms.Label labelEngine;
        private System.Windows.Forms.Label labelCarName;
        private System.Windows.Forms.Label labelColor;
        private System.Windows.Forms.Label labelVIN;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label labelFname;
    }
}
