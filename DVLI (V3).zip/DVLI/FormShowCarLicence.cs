﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLI
{
    public partial class FormShowCarLicence : Form
    {
        public FormShowCarLicence(int CarID)
        {
            InitializeComponent();
            try
            {
        
                userControlShowCarLicence1.ShowInfo(CarID);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Close();
        }

        private void FormShowCarLicence_Load(object sender, EventArgs e)
        {

        }

        private void userControlShowCarLicence1_Load(object sender, EventArgs e)
        {

        }
    }
}
