﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DVLI.Licence;
using Presentation;

namespace DVLI
{
    public partial class FormInternationalDrivingLicence : Form
    {
        public FormInternationalDrivingLicence()
        {
            InitializeComponent();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Close();
        }

        private void buttonIssue_Click(object sender, EventArgs e)
        {
            DateTime dt = userControlLCImfo1.ExDate;
            if (userControlLCImfo1.ExDate < DateTime.Now)
            {
                MessageBox.Show("The License is  Expired");
                return;
            }
            if (userControlLCImfo1.IsActive == 0)
            {
                MessageBox.Show("cant Detain an inactive Licence");
                return;
            }
            if (ClsLicense.IsLicenceDetained(Convert.ToInt32(userControlLCImfo1.dt.Rows[0][0])) == "Yes")
            {
                MessageBox.Show("The License is already Detained");
                return;
            }
            DataRow dr = userControlLCImfo1.dt.Rows[0];
            DataTable dt2 = ClsUsers.SerchByUserName(ClassCurrentUser.userName);
            DataRow dr2 = dt2.Rows[0];
            int ApplicationID = ClsApplication.AddNewApplication(Convert.ToInt32(dr[14]), DateTime.Now, 6, 1, DateTime.Now, 5, Convert.ToInt32(dr2[0]));
            if (ApplicationID == -1)
            {

                MessageBox.Show("Faild");
            }
            else
            {
                
                    

                int LLDId = ClsLicense.AddNewInternationalLicence(ApplicationID, Convert.ToInt32(dr[12]), Convert.ToInt32(userControlLCImfo1.dt.Rows[0][0]), DateTime.Now, ClsLicense.getLicenceclassExpireDate(Convert.ToInt32(dr[15])),1, Convert.ToInt32(dr2[0]));
                if (LLDId == -1)
                    {
                        MessageBox.Show("Faild");

                    }
                    else
                    {

                        MessageBox.Show("Done");
                        DataTable dt1 = ClsLicense.ShowLicenceInfo(LLDId);


                    }


                }



            }
        }
    }

