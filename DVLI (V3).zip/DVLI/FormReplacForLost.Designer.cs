﻿namespace DVLI
{
    partial class FormReplacForLost
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonRenew = new System.Windows.Forms.Button();
            this.userControlLCImfo1 = new DVLI.Licence.UserControlLCImfo();
            this.SuspendLayout();
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(757, 461);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(129, 35);
            this.buttonCancel.TabIndex = 7;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonRenew
            // 
            this.buttonRenew.Location = new System.Drawing.Point(892, 461);
            this.buttonRenew.Name = "buttonRenew";
            this.buttonRenew.Size = new System.Drawing.Size(129, 35);
            this.buttonRenew.TabIndex = 6;
            this.buttonRenew.Text = "Replace";
            this.buttonRenew.UseVisualStyleBackColor = true;
            this.buttonRenew.Click += new System.EventHandler(this.buttonRenew_Click);
            // 
            // userControlLCImfo1
            // 
            this.userControlLCImfo1.ExpirationDateText = "[????]";
            this.userControlLCImfo1.Location = new System.Drawing.Point(3, 12);
            this.userControlLCImfo1.Name = "userControlLCImfo1";
            this.userControlLCImfo1.Size = new System.Drawing.Size(1075, 443);
            this.userControlLCImfo1.TabIndex = 5;
            // 
            // FormReplacForLost
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1107, 522);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonRenew);
            this.Controls.Add(this.userControlLCImfo1);
            this.Name = "FormReplacForLost";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormReplacForLost";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button buttonRenew;
        private Licence.UserControlLCImfo userControlLCImfo1;
    }
}