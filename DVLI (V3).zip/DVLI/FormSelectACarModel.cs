﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DVLI.Licence;
using Presentation;

namespace DVLI
{
    public partial class FormSelectACarModel : Form
    {
        public int prsonID;
      
        public FormSelectACarModel(int PersonID)
        {
            InitializeComponent();
            dataGridView1.DataSource = ClsCar.GetAllCarsModels().DefaultView;
            prsonID = PersonID;
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            
            DataTable dt2 = ClsUsers.SerchByUserName(ClassCurrentUser.userName);
            DataRow dr2 = dt2.Rows[0];
            int ApplicationID = ClsApplication.AddNewApplication(prsonID, DateTime.Now, 1008, 1, DateTime.Now, 15, Convert.ToInt32(dr2[0]));
            if (ApplicationID == -1)
            {

                MessageBox.Show("Faild");
            }
            else
            {
               DataTable dt= ClsUsers.SerchByPersonID(prsonID);
                int CarID = ClsCar.AddNewCar(prsonID, Convert.ToInt32(dt.Rows[0][0]), textBoxCarName.Text, Convert.ToInt32(textBoxEngine.Text), textBoxFule.Text,
                    Convert.ToInt32(textBoxNumOfDoors.Text), Convert.ToInt32(textBoxVIN.Text), textBoxColor.Text, Convert.ToDateTime(label12.Text), Convert.ToDateTime(label13.Text),
                    ClsCar.FeesForReRegister(Convert.ToInt32(textBox1.Text), textBoxFule.Text), Convert.ToInt32(textBox1.Text),textBoxYear.Text);

                if (CarID == -1) 
                  
                {
                    MessageBox.Show("Faild");
                }
                else
                {
                    MessageBox.Show("Done");

                    this.Hide();
                    this.Close();
                    FormShowCarLicence form = new FormShowCarLicence(CarID);
                    form.ShowDialog();




                }



            }

        }

        private void textBoxSerch_TextChanged(object sender, EventArgs e)
        {
            try
            {

                if (textBoxSerch.Text == "")
                {
                    dataGridView1.DataSource = ClsCar.GetAllCarsModels().DefaultView;
                }
                else
                {
                    dataGridView1.DataSource = ClsCar.GetAllCarsModelsBYName(textBoxSerch.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void selectThisCarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataRowView row = (DataRowView)dataGridView1.SelectedRows[0].DataBoundItem;
            textBoxCarName.Text = row[0].ToString();
           textBoxYear.Text = row[1].ToString();
            if (row[2].ToString() == "")
            {
                textBoxEngine.Text = "0";
            }
            else
            {
                textBoxEngine.Text = row[2].ToString();
            }
            if(Convert.ToInt32 (row[3])>=1&& Convert.ToInt32(row[3]) <= 5)
            {
                textBoxFule.Text="EV";
            }
            if (Convert.ToInt32(row[3]) == 6 )
            {
                textBoxFule.Text = "DIESEL";
            }
            if (Convert.ToInt32(row[3]) >= 7 && Convert.ToInt32(row[3]) <= 11)
            {
                textBoxFule.Text = "EV";
            }
            if (Convert.ToInt32(row[3]) >= 12 && Convert.ToInt32(row[3]) <= 13)
            {
                textBoxFule.Text = "HYBRID";
            }
            if (Convert.ToInt32(row[3]) >= 14 && Convert.ToInt32(row[3]) <= 15)
            {
                textBoxFule.Text = "GAS";
            }
            if (Convert.ToInt32(row[3]) >= 16 && Convert.ToInt32(row[3]) <= 17)
            {
                textBoxFule.Text = "HYBRID";
            }

            label12.Text = DateTime.Now.ToShortDateString();
            label13.Text = DateTime.Now.AddYears(1).ToShortDateString();



            textBoxNumOfDoors.Text = row[4].ToString();

            
        labelFees.Text = ClsCar.FeesForRegisterANewCar(Convert.ToInt32(textBoxEngine.Text), Convert.ToInt32(row[1]), textBoxFule.Text).ToString();
            
            


        }

        private void FormSelectACarModel_Load(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }
    }
}
