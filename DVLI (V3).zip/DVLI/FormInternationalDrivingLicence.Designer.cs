﻿namespace DVLI
{
    partial class FormInternationalDrivingLicence
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.userControlLCImfo1 = new DVLI.Licence.UserControlLCImfo();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonIssue = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // userControlLCImfo1
            // 
            this.userControlLCImfo1.ExpirationDateText = "[????]";
            this.userControlLCImfo1.Location = new System.Drawing.Point(10, 10);
            this.userControlLCImfo1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.userControlLCImfo1.Name = "userControlLCImfo1";
            this.userControlLCImfo1.Size = new System.Drawing.Size(921, 360);
            this.userControlLCImfo1.TabIndex = 0;
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(686, 399);
            this.buttonCancel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(111, 19);
            this.buttonCancel.TabIndex = 6;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonIssue
            // 
            this.buttonIssue.Location = new System.Drawing.Point(821, 399);
            this.buttonIssue.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonIssue.Name = "buttonIssue";
            this.buttonIssue.Size = new System.Drawing.Size(111, 19);
            this.buttonIssue.TabIndex = 5;
            this.buttonIssue.Text = "Issue";
            this.buttonIssue.UseVisualStyleBackColor = true;
            this.buttonIssue.Click += new System.EventHandler(this.buttonIssue_Click);
            // 
            // FormInternationalDrivingLicence
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(947, 438);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonIssue);
            this.Controls.Add(this.userControlLCImfo1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormInternationalDrivingLicence";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormInternationalDrivingLicence";
            this.ResumeLayout(false);

        }

        #endregion

        private Licence.UserControlLCImfo userControlLCImfo1;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button buttonIssue;
    }
}