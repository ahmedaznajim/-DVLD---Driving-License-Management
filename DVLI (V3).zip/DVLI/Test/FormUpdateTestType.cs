﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Presentation;

namespace DVLI
{
    public partial class FormUpdateTestType : Form
    {
        public FormUpdateTestType(int TestTypeID, string TestTypeTitle, string TestTypeDescription, int TestTypeFees)
        {
            InitializeComponent();
            labelId.Text = TestTypeID.ToString();
            textBoxApplicationTypeTitle.Text = TestTypeTitle.ToString();
            textBoxApplicationFees.Text = TestTypeFees.ToString();
            richTextBox1.Text=TestTypeDescription.ToString();
            
        }

        private void FormUpdateTestType_Load(object sender, EventArgs e)
        {

        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (ClsTest.UpdateTestType(Convert.ToInt32(labelId.Text), textBoxApplicationTypeTitle.Text, richTextBox1.Text, Convert.ToInt32(textBoxApplicationFees.Text)))
                {
                    MessageBox.Show("Done");
                }
                else
                {
                    MessageBox.Show("Faild");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
    }
}
