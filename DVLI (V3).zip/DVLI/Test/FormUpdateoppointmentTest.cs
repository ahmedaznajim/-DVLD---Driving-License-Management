﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Presentation;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace DVLI
{
    public partial class FormUpdateoppointmentTest : Form
    {
        DataRow row;
        int testId;
        public FormUpdateoppointmentTest (DataRow row, int testId,int IsActive)
        {
            InitializeComponent();
            this.row = row;
          this.testId = testId;
            if (IsActive == 1)
            {
                labelWarrning.Visible = true;
                dateTimePicker1.Visible = false;
                button1.Visible = false;


            }
            if (IsActive == 0)
            {
                labelWarrning.Visible = false;
                dateTimePicker1.Visible = true;
                button1.Visible = true;


            }


            labelDLAPPID.Text = row[0].ToString();
            labelDLCLass.Text = row[13].ToString();

            labelName.Text = row[10].ToString();

            labelFees.Text = row[9].ToString();
        }

        private void FormUpdateoppointmentTest_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ClsTest.UpdatTestOppointment(dateTimePicker1.Value, testId))
            {
                MessageBox.Show("Done");
            }
            else
            {
                MessageBox.Show("Faild");
            }
        }

        private void labelName_Click(object sender, EventArgs e)
        {

        }

        private void labelTrial_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void labelDLAPPID_Click(object sender, EventArgs e)
        {

        }

        private void labelDLCLass_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void labelFees_Click(object sender, EventArgs e)
        {

        }
    }
}
