﻿namespace DVLI
{
    partial class FormLocalDrivingLicenceApplications
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sechudalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.schdualAVisionTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.schdualAWrittenTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.schdualAStreetTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.issueALicenenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.renewDrivingLicenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.replacmentForLostOrDamegedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relaeasLicenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.detainedLicenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.replacmentForLostToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBoxSerch = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.ContextMenuStrip = this.contextMenuStrip1;
            this.dataGridView1.Location = new System.Drawing.Point(24, 333);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(884, 302);
            this.dataGridView1.TabIndex = 11;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteToolStripMenuItem,
            this.deleteToolStripMenuItem1,
            this.refreshToolStripMenuItem,
            this.sechudalToolStripMenuItem,
            this.issueALicenenceToolStripMenuItem,
            this.renewDrivingLicenceToolStripMenuItem,
            this.replacmentForLostOrDamegedToolStripMenuItem,
            this.relaeasLicenceToolStripMenuItem,
            this.detainedLicenceToolStripMenuItem,
            this.replacmentForLostToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(257, 272);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.deleteToolStripMenuItem.Text = "Cancel";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem1
            // 
            this.deleteToolStripMenuItem1.Name = "deleteToolStripMenuItem1";
            this.deleteToolStripMenuItem1.Size = new System.Drawing.Size(256, 24);
            this.deleteToolStripMenuItem1.Text = "Delete";
            this.deleteToolStripMenuItem1.Click += new System.EventHandler(this.deleteToolStripMenuItem1_Click);
            // 
            // refreshToolStripMenuItem
            // 
            this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
            this.refreshToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.refreshToolStripMenuItem.Text = "Refresh";
            this.refreshToolStripMenuItem.Click += new System.EventHandler(this.refreshToolStripMenuItem_Click);
            // 
            // sechudalToolStripMenuItem
            // 
            this.sechudalToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.schdualAVisionTestToolStripMenuItem,
            this.schdualAWrittenTestToolStripMenuItem,
            this.schdualAStreetTestToolStripMenuItem});
            this.sechudalToolStripMenuItem.Name = "sechudalToolStripMenuItem";
            this.sechudalToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.sechudalToolStripMenuItem.Text = "Schdual a test";
            this.sechudalToolStripMenuItem.Click += new System.EventHandler(this.sechudalToolStripMenuItem_Click);
            // 
            // schdualAVisionTestToolStripMenuItem
            // 
            this.schdualAVisionTestToolStripMenuItem.Name = "schdualAVisionTestToolStripMenuItem";
            this.schdualAVisionTestToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.schdualAVisionTestToolStripMenuItem.Text = "Schdual a Vision test";
            this.schdualAVisionTestToolStripMenuItem.Click += new System.EventHandler(this.schdualAVisionTestToolStripMenuItem_Click);
            // 
            // schdualAWrittenTestToolStripMenuItem
            // 
            this.schdualAWrittenTestToolStripMenuItem.Enabled = false;
            this.schdualAWrittenTestToolStripMenuItem.Name = "schdualAWrittenTestToolStripMenuItem";
            this.schdualAWrittenTestToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.schdualAWrittenTestToolStripMenuItem.Text = "Schdual a written test";
            this.schdualAWrittenTestToolStripMenuItem.Click += new System.EventHandler(this.schdualAWrittenTestToolStripMenuItem_Click);
            // 
            // schdualAStreetTestToolStripMenuItem
            // 
            this.schdualAStreetTestToolStripMenuItem.Enabled = false;
            this.schdualAStreetTestToolStripMenuItem.Name = "schdualAStreetTestToolStripMenuItem";
            this.schdualAStreetTestToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.schdualAStreetTestToolStripMenuItem.Text = "Schdual a Street test";
            this.schdualAStreetTestToolStripMenuItem.Click += new System.EventHandler(this.schdualAStreetTestToolStripMenuItem_Click);
            // 
            // issueALicenenceToolStripMenuItem
            // 
            this.issueALicenenceToolStripMenuItem.Enabled = false;
            this.issueALicenenceToolStripMenuItem.Name = "issueALicenenceToolStripMenuItem";
            this.issueALicenenceToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.issueALicenenceToolStripMenuItem.Text = "Issue A Licenence";
            this.issueALicenenceToolStripMenuItem.Click += new System.EventHandler(this.issueALicenenceToolStripMenuItem_Click);
            // 
            // renewDrivingLicenceToolStripMenuItem
            // 
            this.renewDrivingLicenceToolStripMenuItem.Name = "renewDrivingLicenceToolStripMenuItem";
            this.renewDrivingLicenceToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.renewDrivingLicenceToolStripMenuItem.Text = "Renew Driving Licence";
            this.renewDrivingLicenceToolStripMenuItem.Click += new System.EventHandler(this.renewDrivingLicenceToolStripMenuItem_Click);
            // 
            // replacmentForLostOrDamegedToolStripMenuItem
            // 
            this.replacmentForLostOrDamegedToolStripMenuItem.Name = "replacmentForLostOrDamegedToolStripMenuItem";
            this.replacmentForLostOrDamegedToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.replacmentForLostOrDamegedToolStripMenuItem.Text = "Replacment For Dameged ";
            this.replacmentForLostOrDamegedToolStripMenuItem.Click += new System.EventHandler(this.replacmentForLostOrDamegedToolStripMenuItem_Click);
            // 
            // relaeasLicenceToolStripMenuItem
            // 
            this.relaeasLicenceToolStripMenuItem.Name = "relaeasLicenceToolStripMenuItem";
            this.relaeasLicenceToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.relaeasLicenceToolStripMenuItem.Text = "Relaeas Licence";
            // 
            // detainedLicenceToolStripMenuItem
            // 
            this.detainedLicenceToolStripMenuItem.Name = "detainedLicenceToolStripMenuItem";
            this.detainedLicenceToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.detainedLicenceToolStripMenuItem.Text = "Detained Licence";
            // 
            // replacmentForLostToolStripMenuItem
            // 
            this.replacmentForLostToolStripMenuItem.Name = "replacmentForLostToolStripMenuItem";
            this.replacmentForLostToolStripMenuItem.Size = new System.Drawing.Size(256, 24);
            this.replacmentForLostToolStripMenuItem.Text = "Replacment For Lost ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(244, 203);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(472, 33);
            this.label1.TabIndex = 10;
            this.label1.Text = "Local Driving Licence Applications";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DVLI.Properties.Resources.drivers_license;
            this.pictureBox1.Location = new System.Drawing.Point(327, 15);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(260, 171);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // textBoxSerch
            // 
            this.textBoxSerch.Location = new System.Drawing.Point(269, 300);
            this.textBoxSerch.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSerch.Name = "textBoxSerch";
            this.textBoxSerch.Size = new System.Drawing.Size(116, 24);
            this.textBoxSerch.TabIndex = 14;
            this.textBoxSerch.TextChanged += new System.EventHandler(this.textBoxSerch_TextChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "None",
            "LastName",
            "ID",
            "National No"});
            this.comboBox1.Location = new System.Drawing.Point(117, 301);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(140, 24);
            this.comboBox1.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 301);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 21);
            this.label2.TabIndex = 12;
            this.label2.Text = "Filter By";
            // 
            // FormLocalDrivingLicenceApplications
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(912, 648);
            this.Controls.Add(this.textBoxSerch);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormLocalDrivingLicenceApplications";
            this.Text = "FormLocalDrivingLicenceApplications";
            this.Load += new System.EventHandler(this.FormLocalDrivingLicenceApplications_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sechudalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem schdualAVisionTestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem schdualAWrittenTestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem schdualAStreetTestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem issueALicenenceToolStripMenuItem;
        private System.Windows.Forms.TextBox textBoxSerch;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem renewDrivingLicenceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem replacmentForLostOrDamegedToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relaeasLicenceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem detainedLicenceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem replacmentForLostToolStripMenuItem;
    }
}