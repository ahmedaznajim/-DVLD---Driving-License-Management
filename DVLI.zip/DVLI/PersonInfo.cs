﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DVLI.Properties;
using Business;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Reflection.Emit;


namespace DVLI
{
    public partial class PersonInfo : UserControl
    {
        public PersonInfo()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonF.Checked)
            {
                pictureBox1.Image = Resources.girl;

            }
            else
            {
                if (radioButtonM.Checked)
                {
                    pictureBox1.Image = Resources.boy;

                }

            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonF.Checked)
            {
                pictureBox1.Image = Resources.girl;

            }
            else
            {
                if (radioButtonM.Checked)
                {
                    pictureBox1.Image = Resources.boy;

                }

            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {


         
        }

        private void labelID_Click(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            FormAddPerson s=new FormAddPerson();
            s.Close();
        }

        private void PersonInfo_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Person.SerchByNationalNumber(textBoxNational.Text))
            {
                MessageBox.Show("The National Number is already Exits");
                textBoxNational.Clear();

            }
            else
            {


                if (Person.AddPerson(textBoxNational.Text, textBoxfname.Text, textBoxSname.Text,
                   textBoxTName.Text, textBoxLanem.Text, dateTimePicker2.Value,
          0, richTextBoxadrss.Text, textBoxPname.Text, textBoxEmail.Text,
             1, pictureBox1.ToString()) == -1)
                {
                    MessageBox.Show("Error");

                }
                else
                {
                    MessageBox.Show("Saved Correctly");
                    textBoxNational.Clear();
                    textBoxfname.Clear();
                    textBoxSname.Clear();
                    textBoxTName.Clear();
                    textBoxLanem.Clear();
                    dateTimePicker2.Value = DateTime.Now;
                    richTextBoxadrss.Clear();
                    textBoxPname.Clear();
                    textBoxEmail.Clear();

                }


            }
        }
        private void textBoxNational_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void richTextBoxadrss_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBoxCountry_TextChanged(object sender, EventArgs e)
        {

        }

        private void Country_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBoxEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxPname_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxLanem_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxTName_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxSname_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxfname_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
