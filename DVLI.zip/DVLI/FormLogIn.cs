﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Presentation;

namespace DVLI
{
    public partial class FormLogIn : Form
    {
        public FormLogIn()
        {
            InitializeComponent();
        }

        private void buttonLogIn_Click(object sender, EventArgs e)
        {
            int s = ClsUsers.CheckUserLogInInfo(textBoxUserName.Text, textBoxPassword.Text);
            if (s==0)
            {
              
                FormMenue formMenue = new FormMenue(textBoxUserName.Text);
                this.Hide();
                formMenue.ShowDialog();
               this.Close();
            }
            else
            {
                if (s == 1)
                {
                    MessageBox.Show("The Password or the user name is incorrect");
                }
                if (s == 2)
                {
                    MessageBox.Show("The was deativated");
                }

            }
        }
    }
}
