﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Presentation;

namespace DVLI.Licence
{
    public partial class FormViewLicenceHistory : Form
    {
        int DriverID;
        public FormViewLicenceHistory(int DriverID)

        {
            InitializeComponent();
            this.DriverID = DriverID;
            dataGridView1.DataSource = ClsLicense.getLicensesHistoryForADriver(DriverID);
        }

        private void FormViewLicenceHistory_Load(object sender, EventArgs e)
        {

        }

        private void viewLicenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = ClsLicense.ShowLicenceInfo(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value));
                FormViewDrivingLicenceInfromations form = new FormViewDrivingLicenceInfromations(dt);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please Select a Licence");
            }
        }

        private void renewDrivingLicenceToolStripMenuItem_Click(object sender, EventArgs e)
        {

            int ApplicationID = ClsApplication.AddNewApplication(Convert.ToInt32(dataGridView1.Rows[0].Cells[12].Value), DateTime.Now, 2, 1, DateTime.Now, 5, 1);
            if (ApplicationID == -1)
            {

                MessageBox.Show("Faild");
            }
            else
            {
                if (ClsLicense.DeactivateLocalDrivingLicence(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value)))
                {
                    int LLDId = ClsLicense.AddNewLicence(ApplicationID, Convert.ToInt32(dataGridView1.Rows[0].Cells[2].Value)
                        , Convert.ToInt32(dataGridView1.Rows[0].Cells[3].Value), DateTime.Now, ClsLicense.getLicenceclassExpireDate(Convert.ToInt32(dataGridView1.Rows[0].Cells[3].Value)),
                        " ", 20, 1, 2, 1);
                    if (LLDId == -1)
                    {
                        MessageBox.Show("Faild");

                    }
                    else
                    {

                        MessageBox.Show("Done");
                        dataGridView1.DataSource = ClsLicense.getLicensesHistoryForADriver(DriverID);
                    }


                }



            }
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ClsLicense.getLicensesHistoryForADriver(DriverID);
        }

        private void replacmentForDamegedToolStripMenuItem_Click(object sender, EventArgs e)
        {


        }

        private void relaeasLicenceToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void replacmentForDamegedToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            int ApplicationID = ClsApplication.AddNewApplication(Convert.ToInt32(dataGridView1.Rows[0].Cells[12].Value), DateTime.Now, 4, 1, DateTime.Now, 5, 1);
            if (ApplicationID == -1)
            {

                MessageBox.Show("Faild");
            }
            else
            {
                if (ClsLicense.DeactivateLocalDrivingLicence(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value)))
                {
                    int LLDId = ClsLicense.AddNewLicence(ApplicationID, Convert.ToInt32(dataGridView1.Rows[0].Cells[2].Value)
                        , Convert.ToInt32(dataGridView1.Rows[0].Cells[3].Value), DateTime.Now, ClsLicense.getLicenceclassExpireDate(Convert.ToInt32(dataGridView1.Rows[0].Cells[3].Value)),
                        " ", 20, 1, 3, 1);
                    if (LLDId == -1)
                    {
                        MessageBox.Show("Faild");

                    }
                    else
                    {

                        MessageBox.Show("Done");
                        dataGridView1.DataSource = ClsLicense.getLicensesHistoryForADriver(DriverID);
                    }


                }



            }
        }

        private void replacmentForLostToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int ApplicationID = ClsApplication.AddNewApplication(Convert.ToInt32(dataGridView1.Rows[0].Cells[12].Value), DateTime.Now, 3, 1, DateTime.Now, 5, 1);
            if (ApplicationID == -1)
            {

                MessageBox.Show("Faild");
            }
            else
            {
                if (ClsLicense.DeactivateLocalDrivingLicence(Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value)))
                {
                    int LLDId = ClsLicense.AddNewLicence(ApplicationID, Convert.ToInt32(dataGridView1.Rows[0].Cells[2].Value)
                        , Convert.ToInt32(dataGridView1.Rows[0].Cells[3].Value), DateTime.Now, ClsLicense.getLicenceclassExpireDate(Convert.ToInt32(dataGridView1.Rows[0].Cells[3].Value)),
                        " ", 20, 1, 4, 1);
                    if (LLDId == -1)
                    {
                        MessageBox.Show("Faild");

                    }
                    else
                    {

                        MessageBox.Show("Done");
                        dataGridView1.DataSource = ClsLicense.getLicensesHistoryForADriver(DriverID);
                    }


                }



            }
        }
        
        private void detainedLicenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(dataGridView1.Rows[0].Cells[8].Value) == 0) {
            MessageBox.Show("cant Detain an inactive Licence");
                return;
            }

            if (ClsLicense.IsDetaindedExist(Convert.ToInt32(dataGridView1.Rows[0].Cells[0].Value)))
            {
                MessageBox.Show("This Licence is already Detained");
                return;
            }
            else
            {
                DateTime dateTime = DateTime.Now.AddYears(10);
                if (ClsLicense.DetainLicenec(Convert.ToInt32(dataGridView1.Rows[0].Cells[0].Value), DateTime.Now, 5, 1, 0, dateTime, 0, 0) == -1)
                {
                    MessageBox.Show("Faild");
                }
                else
                {
                    MessageBox.Show("Done");
                    dataGridView1.DataSource = ClsLicense.getLicensesHistoryForADriver(DriverID);
                }
            }
        }
    }
}
