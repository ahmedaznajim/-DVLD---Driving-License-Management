﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business;
using Presentation;

namespace DVLI
{
    public partial class FormUpdateUser : Form
    {
        DataTable dt = new DataTable();
        DataRow row1;
        int UserID;
        int PersonID;
        string UserName;
        string Password;
        int IsActive;
        public FormUpdateUser(int UserID, int PersonID, string UserName,
       string Password, int IsActive)
        {
            InitializeComponent();
            dt = Person.GetPplInfo();
            foreach (DataRow row in dt.Rows)
            {
                comboBox1.Items.Add(row[3].ToString());


            }

            this.UserID = UserID;
            this.PersonID = PersonID;
            this.UserName = UserName;
            this.Password = Password;
            this.IsActive = IsActive;
        
            textBoxUserName.Text = UserName;
            textBoxpassword.Text = Password;
            if (IsActive == 1)
            {
                radioButtonY.Checked = true;
                radioButtonN.Checked = false;

            }
            if (IsActive == 0)
            {
                radioButtonY.Checked = false;
                radioButtonN.Checked = true;

            }
            
            labelId.Text = UserID.ToString();


        }

        private void FormUpdateUser_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            try
            {
                row1 = dt.Rows[comboBox1.SelectedIndex];
                if (ClsUsers.UpdatUser(UserID, Convert.ToInt32(row1[0]), UserName, Password, IsActive))
                {

                    MessageBox.Show("Done");
                }
                else
                {
                    MessageBox.Show("Faild");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            }
            
        
    }
}
