﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using Presentation;

namespace DVLI
{
    public partial class FormShowUserInfo : Form
    {
        DataTable dt = new DataTable();
        DataRow row1;
        public FormShowUserInfo(int ID, string NationalNo, string FirstName, string SecondName, string ThirdName, string LastName, string DateOfBirth,
          int Gendor, string Address, string Phone, string Email,
             int NationalityCountryID, string ImagePath)
        {
            InitializeComponent();
            dt=ClsCountry.GetCountries();
            comboBox1.Enabled = false;

            foreach (DataRow row in dt.Rows)
            {
                comboBox1.Items.Add(row[1].ToString());


            }

            labelId.Text = Convert.ToString(ID);
           labelNo.Text = NationalNo;
            labelfname.Text = FirstName;
            labelsname.Text = SecondName;
            labeltname.Text = ThirdName;
            labeltname.Text = LastName;
            labelBirth.Text = DateOfBirth.ToString();
            if (Gendor == 0)
            {
                labelGender.Text = "Male";
            }
            if (Gendor == 1)
            {
                labelGender.Text = "Female";
            }
            labelAdress.Text = Address;

            labelphone.Text = Phone;
            labelEmail.Text = Email;
             comboBox1.SelectedIndex=NationalityCountryID-1;
            try
            {
                pictureBox1.Image = Image.FromFile(ImagePath);
            }
            catch { }

        }

        private void FormShowUserInfo_Load(object sender, EventArgs e)
        {

        }
    }
}
