﻿namespace DVLI
{
    partial class FormTakingTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.labelTrial = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelDLAPPID = new System.Windows.Forms.Label();
            this.labelDLCLass = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButtonPass = new System.Windows.Forms.RadioButton();
            this.radioButtonFaild = new System.Windows.Forms.RadioButton();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 30;
            this.label2.Text = "Name";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(103, 114);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(17, 13);
            this.labelName.TabIndex = 31;
            this.labelName.Text = "??";
            // 
            // labelTrial
            // 
            this.labelTrial.AutoSize = true;
            this.labelTrial.Location = new System.Drawing.Point(103, 159);
            this.labelTrial.Name = "labelTrial";
            this.labelTrial.Size = new System.Drawing.Size(17, 13);
            this.labelTrial.TabIndex = 32;
            this.labelTrial.Text = "??";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 159);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 33;
            this.label6.Text = "Trial";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "DL.App ID";
            // 
            // labelDLAPPID
            // 
            this.labelDLAPPID.AutoSize = true;
            this.labelDLAPPID.Location = new System.Drawing.Point(103, 23);
            this.labelDLAPPID.Name = "labelDLAPPID";
            this.labelDLAPPID.Size = new System.Drawing.Size(17, 13);
            this.labelDLAPPID.TabIndex = 27;
            this.labelDLAPPID.Text = "??";
            // 
            // labelDLCLass
            // 
            this.labelDLCLass.AutoSize = true;
            this.labelDLCLass.Location = new System.Drawing.Point(103, 68);
            this.labelDLCLass.Name = "labelDLCLass";
            this.labelDLCLass.Size = new System.Drawing.Size(17, 13);
            this.labelDLCLass.TabIndex = 28;
            this.labelDLCLass.Text = "??";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 29;
            this.label4.Text = "Class";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtonFaild);
            this.groupBox1.Controls.Add(this.radioButtonPass);
            this.groupBox1.Location = new System.Drawing.Point(12, 190);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(158, 67);
            this.groupBox1.TabIndex = 34;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Result";
            // 
            // radioButtonPass
            // 
            this.radioButtonPass.AutoSize = true;
            this.radioButtonPass.Location = new System.Drawing.Point(6, 29);
            this.radioButtonPass.Name = "radioButtonPass";
            this.radioButtonPass.Size = new System.Drawing.Size(47, 17);
            this.radioButtonPass.TabIndex = 0;
            this.radioButtonPass.TabStop = true;
            this.radioButtonPass.Text = "Pass";
            this.radioButtonPass.UseVisualStyleBackColor = true;
            // 
            // radioButtonFaild
            // 
            this.radioButtonFaild.AutoSize = true;
            this.radioButtonFaild.Location = new System.Drawing.Point(94, 29);
            this.radioButtonFaild.Name = "radioButtonFaild";
            this.radioButtonFaild.Size = new System.Drawing.Size(47, 17);
            this.radioButtonFaild.TabIndex = 1;
            this.radioButtonFaild.TabStop = true;
            this.radioButtonFaild.Text = "Faild";
            this.radioButtonFaild.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(12, 302);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(279, 96);
            this.richTextBox1.TabIndex = 35;
            this.richTextBox1.Text = "";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 275);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 36;
            this.label3.Text = "Note:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(216, 415);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 37;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormTakingTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(331, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.labelTrial);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelDLAPPID);
            this.Controls.Add(this.labelDLCLass);
            this.Controls.Add(this.label4);
            this.Name = "FormTakingTest";
            this.Text = "FormTakingTest";
            this.Load += new System.EventHandler(this.FormTakingTest_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelTrial;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelDLAPPID;
        private System.Windows.Forms.Label labelDLCLass;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButtonFaild;
        private System.Windows.Forms.RadioButton radioButtonPass;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
    }
}