﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Presentation;

namespace DVLI
{
    public partial class FormTakingTest : Form
    {
        DataRow row;
        int testId;
        int TestType;
        public FormTakingTest(DataRow row, int testId, int TestType)
        {
            InitializeComponent();
            this.TestType = TestType;
            this.row = row;
            this.testId = testId;

            labelDLAPPID.Text = row[0].ToString();
            labelDLCLass.Text = row[13].ToString();

            labelName.Text = row[10].ToString();

            
        }

        private void FormTakingTest_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButtonPass.Checked)
            {
                if (TestType == 0)
                {
                    if (ClsTest.PassVidionTestDateTime(testId, Convert.ToInt32(row[1])))
                    {

                        MessageBox.Show("Done");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Faild");

                    }
                }
                if (TestType == 1)
                {
                    if (ClsTest.PassWrittenTestDateTime(testId, Convert.ToInt32(row[1])))
                    {

                        MessageBox.Show("Done");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Faild");

                    }
                }
                if (TestType == 2)
                {
                    if (ClsTest.PassStreetTestDateTime(testId, Convert.ToInt32(row[1])))
                    {
                        ClsApplication.SetStatuesToComplete(Convert.ToInt32(row[1]));
                        MessageBox.Show("Done");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Faild");

                    }
                }




            }

            if (radioButtonFaild.Checked)
            {
                if (ClsTest.FaildVidionTestDateTime(testId))
                {

                    MessageBox.Show("Done");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Faild");

                }



            }

        }
    }
}
