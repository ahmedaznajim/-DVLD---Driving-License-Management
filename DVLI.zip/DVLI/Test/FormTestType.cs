﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Presentation;

namespace DVLI
{
    public partial class FormTestType : Form
    {
        public FormTestType()
        {
            InitializeComponent();

            dataGridView1.DataSource = ClsTest.GetAllTestType();
        }

        private void FormTestType_Load(object sender, EventArgs e)
        {

        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

               FormUpdateTestType formUpdateTestType=new FormUpdateTestType(
                      Convert.ToInt32(selectedRow.Cells[0].Value),
                     Convert.ToString(selectedRow.Cells[1].Value),
                     Convert.ToString(selectedRow.Cells[2].Value),
                     Convert.ToInt32(selectedRow.Cells[3].Value)


                 );

                formUpdateTestType.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select a row first.");
            }
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {

            dataGridView1.DataSource = ClsTest.GetAllTestType();
        }

        private void sToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void sechduleAVisionTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormVisionTest formVision=new FormVisionTest(Convert.ToInt32(dataGridView1.SelectedRows[0]));
            formVision.ShowDialog();

        }

        private void sechduleAStreetTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormVisionTest formVision = new FormVisionTest(Convert.ToInt32(dataGridView1.SelectedRows[0]));
            formVision.ShowDialog();
        }

        private void contextMenuStrip2_Opening(object sender, CancelEventArgs e)
        {

            
        }

        private void contextMenuStrip2_Click(object sender, EventArgs e)
        {
           


            
        }

        private void sToolStripMenuItem_DoubleClick(object sender, EventArgs e)
        {

          
        }
    }
}
