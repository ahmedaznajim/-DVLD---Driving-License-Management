﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Presentation;

namespace DVLI
{
    public partial class FormVisionTest : Form
    {
        int ApplicationID;
        DataTable DataTable;
        DataRow row;
        public FormVisionTest(int ApplicationID)
        {
            InitializeComponent();
           
            this.ApplicationID = ApplicationID;
          
            DataTable = ClsApplication.GetApplicationsByAppID(ApplicationID);
             row=DataTable.Rows[0];
            labelDLAPPID.Text = row[2].ToString();
            labelDLCLass.Text = row[13].ToString();
            if (row[11].ToString() == "")
            {
                labelPassedTests.Text = "0";
            }
            else
            {
                labelPassedTests.Text = row[11].ToString();
            }
            labelId.Text = row[1].ToString();
            labelSataus.Text = row[7].ToString();
            labelType.Text = row[6].ToString();
            labelDate.Text = row[5].ToString();
            labelCreatedBy.Text = row[4].ToString();
            labelstatusType.Text = row[8].ToString();
            labelfees.Text = row[9].ToString();
         
            dataGridView1.DataSource = ClsTest.GetVisionTestOppointmentsByLDID(Convert.ToInt32(row[0]));


        }

        private void FormVisionTest_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (labelPassedTests.Text == "1")
            {
                MessageBox.Show("You Have allredy Passed This Test");

            }
            else {
                int Islocked = 1;

                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    int v = Convert.ToInt32(dataGridView1.Rows[i].Cells[6].Value);
                    if (v == 0)
                    {
                        Islocked = 2;
                        break;
                    }

                }
                if (Islocked == 1)
                {
                    if (dataGridView1.Rows.Count > 0)
                    {
                        FormAddTestAppointment formAddTest = new FormAddTestAppointment(row, 1, Convert.ToInt32(row[4]));
                        formAddTest.ShowDialog();

                    }
                    if (dataGridView1.Rows.Count == 0)
                    {
                        FormAddTestAppointment formAddTest = new FormAddTestAppointment(row, 0, Convert.ToInt32(row[4]));
                        formAddTest.ShowDialog();

                    }
                }
                if (Islocked == 2)
                {
                    MessageBox.Show("There is already an active oppointment");

                }

            }

        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
           FormUpdateoppointmentTest form=new FormUpdateoppointmentTest(row, Convert.ToInt32 (dataGridView1.SelectedRows[0].Cells[0].Value), Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[6].Value));
            form.ShowDialog();
                
        }

        private void takeTheTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[6].Value) == 0)
            {
                FormTakingTest form = new FormTakingTest(row, Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value),0);
                form.ShowDialog();
            }
            else
            {

                MessageBox.Show("This Test Was Taken ");
            }
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ClsTest.GetVisionTestOppointmentsByLDID(Convert.ToInt32(row[0]));
        }

        private void labelCreatedBy_Click(object sender, EventArgs e)
        {

        }
    }
}
