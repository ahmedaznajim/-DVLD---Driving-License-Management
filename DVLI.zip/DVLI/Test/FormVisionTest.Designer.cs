﻿namespace DVLI
{
    partial class FormVisionTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.labelDLAPPID = new System.Windows.Forms.Label();
            this.labelDLCLass = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelPassedTests = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.labelviewInfo = new System.Windows.Forms.Label();
            this.labelDate = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.labelCreatedBy = new System.Windows.Forms.Label();
            this.labelstatusType = new System.Windows.Forms.Label();
            this.labelType = new System.Windows.Forms.Label();
            this.labelfees = new System.Windows.Forms.Label();
            this.labelSataus = new System.Windows.Forms.Label();
            this.labelId = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.updateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.takeTheTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.labelDLAPPID);
            this.groupBox1.Controls.Add(this.labelDLCLass);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.labelPassedTests);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Location = new System.Drawing.Point(12, 30);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(538, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Driving Licence Application Information";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "DL.App ID";
            // 
            // labelDLAPPID
            // 
            this.labelDLAPPID.AutoSize = true;
            this.labelDLAPPID.Location = new System.Drawing.Point(81, 30);
            this.labelDLAPPID.Name = "labelDLAPPID";
            this.labelDLAPPID.Size = new System.Drawing.Size(17, 13);
            this.labelDLAPPID.TabIndex = 2;
            this.labelDLAPPID.Text = "??";
            // 
            // labelDLCLass
            // 
            this.labelDLCLass.AutoSize = true;
            this.labelDLCLass.Location = new System.Drawing.Point(342, 30);
            this.labelDLCLass.Name = "labelDLCLass";
            this.labelDLCLass.Size = new System.Drawing.Size(17, 13);
            this.labelDLCLass.TabIndex = 3;
            this.labelDLCLass.Text = "??";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(263, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Applied For";
            // 
            // labelPassedTests
            // 
            this.labelPassedTests.AutoSize = true;
            this.labelPassedTests.Location = new System.Drawing.Point(236, 72);
            this.labelPassedTests.Name = "labelPassedTests";
            this.labelPassedTests.Size = new System.Drawing.Size(17, 13);
            this.labelPassedTests.TabIndex = 5;
            this.labelPassedTests.Text = "??";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(162, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Passed tests";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.labelviewInfo);
            this.groupBox2.Controls.Add(this.labelDate);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.labelCreatedBy);
            this.groupBox2.Controls.Add(this.labelstatusType);
            this.groupBox2.Controls.Add(this.labelType);
            this.groupBox2.Controls.Add(this.labelfees);
            this.groupBox2.Controls.Add(this.labelSataus);
            this.groupBox2.Controls.Add(this.labelId);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(12, 136);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(538, 167);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Application Basic Info";
            // 
            // labelviewInfo
            // 
            this.labelviewInfo.AutoSize = true;
            this.labelviewInfo.Location = new System.Drawing.Point(367, 151);
            this.labelviewInfo.Name = "labelviewInfo";
            this.labelviewInfo.Size = new System.Drawing.Size(88, 13);
            this.labelviewInfo.TabIndex = 128;
            this.labelviewInfo.Text = "View Person Info";
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new System.Drawing.Point(438, 41);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(17, 13);
            this.labelDate.TabIndex = 127;
            this.labelDate.Text = "??";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(342, 41);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(30, 13);
            this.label11.TabIndex = 126;
            this.label11.Text = "Date";
            // 
            // labelCreatedBy
            // 
            this.labelCreatedBy.AutoSize = true;
            this.labelCreatedBy.Location = new System.Drawing.Point(438, 103);
            this.labelCreatedBy.Name = "labelCreatedBy";
            this.labelCreatedBy.Size = new System.Drawing.Size(17, 13);
            this.labelCreatedBy.TabIndex = 125;
            this.labelCreatedBy.Text = "??";
            this.labelCreatedBy.Click += new System.EventHandler(this.labelCreatedBy_Click);
            // 
            // labelstatusType
            // 
            this.labelstatusType.AutoSize = true;
            this.labelstatusType.Location = new System.Drawing.Point(438, 72);
            this.labelstatusType.Name = "labelstatusType";
            this.labelstatusType.Size = new System.Drawing.Size(17, 13);
            this.labelstatusType.TabIndex = 124;
            this.labelstatusType.Text = "??";
            // 
            // labelType
            // 
            this.labelType.AutoSize = true;
            this.labelType.Location = new System.Drawing.Point(123, 140);
            this.labelType.Name = "labelType";
            this.labelType.Size = new System.Drawing.Size(17, 13);
            this.labelType.TabIndex = 123;
            this.labelType.Text = "??";
            // 
            // labelfees
            // 
            this.labelfees.AutoSize = true;
            this.labelfees.Location = new System.Drawing.Point(123, 109);
            this.labelfees.Name = "labelfees";
            this.labelfees.Size = new System.Drawing.Size(17, 13);
            this.labelfees.TabIndex = 122;
            this.labelfees.Text = "??";
            // 
            // labelSataus
            // 
            this.labelSataus.AutoSize = true;
            this.labelSataus.Location = new System.Drawing.Point(123, 78);
            this.labelSataus.Name = "labelSataus";
            this.labelSataus.Size = new System.Drawing.Size(17, 13);
            this.labelSataus.TabIndex = 121;
            this.labelSataus.Text = "??";
            // 
            // labelId
            // 
            this.labelId.AutoSize = true;
            this.labelId.Location = new System.Drawing.Point(123, 41);
            this.labelId.Name = "labelId";
            this.labelId.Size = new System.Drawing.Size(17, 13);
            this.labelId.TabIndex = 120;
            this.labelId.Text = "??";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(21, 41);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(18, 13);
            this.label10.TabIndex = 119;
            this.label10.Text = "ID";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(342, 103);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 13);
            this.label9.TabIndex = 118;
            this.label9.Text = "Created By";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(342, 72);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 13);
            this.label8.TabIndex = 117;
            this.label8.Text = "Status Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 116;
            this.label2.Text = "Type";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 115;
            this.label3.Text = "Fees";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 114;
            this.label5.Text = "Status";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 318);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 13);
            this.label7.TabIndex = 129;
            this.label7.Text = "Appointment";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.ContextMenuStrip = this.contextMenuStrip1;
            this.dataGridView1.Location = new System.Drawing.Point(12, 334);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(547, 104);
            this.dataGridView1.TabIndex = 131;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.updateToolStripMenuItem,
            this.takeTheTestToolStripMenuItem,
            this.refreshToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(143, 70);
            // 
            // updateToolStripMenuItem
            // 
            this.updateToolStripMenuItem.Name = "updateToolStripMenuItem";
            this.updateToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.updateToolStripMenuItem.Text = "Update";
            this.updateToolStripMenuItem.Click += new System.EventHandler(this.updateToolStripMenuItem_Click);
            // 
            // takeTheTestToolStripMenuItem
            // 
            this.takeTheTestToolStripMenuItem.Name = "takeTheTestToolStripMenuItem";
            this.takeTheTestToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.takeTheTestToolStripMenuItem.Text = "Take The Test";
            this.takeTheTestToolStripMenuItem.Click += new System.EventHandler(this.takeTheTestToolStripMenuItem_Click);
            // 
            // refreshToolStripMenuItem
            // 
            this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
            this.refreshToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.refreshToolStripMenuItem.Text = "Refresh";
            this.refreshToolStripMenuItem.Click += new System.EventHandler(this.refreshToolStripMenuItem_Click);
            // 
            // button1
            // 
            this.button1.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.button1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button1.Location = new System.Drawing.Point(534, 309);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(25, 22);
            this.button1.TabIndex = 130;
            this.button1.Text = "+";
            this.button1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormVisionTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(588, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormVisionTest";
            this.Text = "FormVisionTest";
            this.Load += new System.EventHandler(this.FormVisionTest_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelDLAPPID;
        private System.Windows.Forms.Label labelDLCLass;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelPassedTests;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label labelviewInfo;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label labelCreatedBy;
        private System.Windows.Forms.Label labelstatusType;
        private System.Windows.Forms.Label labelType;
        private System.Windows.Forms.Label labelfees;
        private System.Windows.Forms.Label labelSataus;
        private System.Windows.Forms.Label labelId;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem updateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem takeTheTestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;
    }
}